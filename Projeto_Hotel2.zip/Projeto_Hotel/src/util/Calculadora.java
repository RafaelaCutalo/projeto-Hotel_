package util;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Date;

public class Calculadora {

	public static BigDecimal calcularPrecoTotal(Date inicio, Date fim, BigDecimal valorDiaria) {
		long qtdDias = Duration.between(inicio.toInstant(), fim.toInstant()).toDays();
		qtdDias += 1; 
		
		return valorDiaria.multiply(new BigDecimal(qtdDias));
	}
	
}
