package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.HospedeDao;
import dao.QuartoDao;
import modelo.Hospede;
import modelo.Quarto;

@WebServlet("/cadastraHospedes")
public class CadastraHospedes extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter out = resp.getWriter();
		//buscando os parâmetros no request
		        String nome = req.getParameter("nome");
		        String cpf = req.getParameter("cpf");
		        String endereco = req.getParameter("endereco");
//		        String numeroQuarto = request.getParameter("numeroQuarto");
//		        String dataEntrada = request.getParameter("dataEntrada");
//		        String dataSaida = request.getParameter("dataSaida");

		//monta um objeto contato
		        Hospede hospede = new Hospede();		        
		        hospede.setNome(nome);
		        hospede.setCpf(cpf);
		        hospede.setEndereco(endereco);
		        
//		        QuartoHotel quartoHotel = new QuartoHotel();
//		        // Integer.valueOf() -> Converter para "int"
//		        quartoHotel.setNumeroQuarto(Integer.valueOf(numeroQuarto));
//		        quartoHotel.setOcupado(true);
//		        
//		        Reserva reserva = new Reserva();
//		        reserva.setDataEntrada(dataEntrada);
//		        reserva.setDataSaida(dataSaida);
//		        reserva.associaHospedeAoQuarto(hospede);
		        
		
//			// salva o contato
			HospedeDao hospedeDao = new HospedeDao();
			hospedeDao.inserir(hospede);
						
			out.println("<html>");
			out.println("<body>");
			out.println("O hospede " + hospede.getNome() + " foi cadastrado com sucesso");
			out.println("<a href='cadastro-hospede.jsp'>Voltar</a>");
			out.println("</body>");
			out.println("</html>");
			
	}
	
	
}
