package config;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import service.QuartoService;

@Startup
@Singleton
public class ApplicationConfig {

	@Inject
	private QuartoService quartoService;
	
	@PostConstruct
	public void init() {
		quartoService.cadastrarQuartosSeNecessario();
	}
	
}