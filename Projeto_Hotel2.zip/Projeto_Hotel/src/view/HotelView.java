package view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

import exception.HotelException;
import modelo.Hospede;
import modelo.Quarto;
import modelo.Reserva;
import service.QuartoService;
import service.ReservaService;
import util.Calculadora;

@Named("hotelView")
@ViewScoped
public class HotelView implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@EJB
	private ReservaService reservaService;

	@EJB
	private QuartoService quartoService;
	
	private Reserva filtroDisponibilidade = new Reserva();
	private List<Quarto> quartosDisponiveis = new ArrayList<Quarto>();
	
	private Reserva reserva = new Reserva();
	
	private Reserva filtroPesquisa = new Reserva();
	private List<Reserva> reservasList = null;
	
	private int step = 0;	
	
	@PostConstruct
	public void init() {
		reserva.setQuarto(new Quarto());
		reserva.setHospede(new Hospede());
	}
	
	public List<Quarto> getQuartosDisponiveis() {
		return quartosDisponiveis;
	}
	
	public void filtrarReservas() {
		reservasList = reservaService.pesquisarReservas(filtroPesquisa);
	}

	public void visualizar(Reserva reserva) {
		this.reserva = reserva;
	}
	
	public void cancelar(Reserva reserva) {
		reservaService.cancelar(reserva.getId());
		
		filtrarReservas();
		
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Sucesso",  "Reserva cancelada com sucesso") );
	}

	public void alterar() {
		reservaService.alterar(reserva);
		
		filtrarReservas();
		
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Sucesso",  "Reserva alterada com sucesso") );
	}

	
	//////////////////////// DISPONIBILIDADE DE QUARTO
	
	public void pesquisarDisponibilidade() {
		
//		if (filtroDisponibilidade.getDataEntrada().compareTo(filtroDisponibilidade.getDataSaida()) > 0) {
//			throw new HotelException("Data de Saída inferior a data de entrada!");
//		}
		
		step = 1;
		
		reserva = new Reserva();
		reserva.setQuarto(new Quarto());
		reserva.setHospede(new Hospede());
		quartosDisponiveis = quartoService.pesquisarQuartosDisponiveis(filtroDisponibilidade.getDataEntrada(), filtroDisponibilidade.getDataSaida());
	}
	
	public void solicitarDadosReserva(Quarto quarto) {
		step = 2;

		Date dataEntrada = filtroDisponibilidade.getDataEntrada();
		Date dataSaida = filtroDisponibilidade.getDataSaida();

		reserva.setQuarto(quarto);
		reserva.setDataEntrada(dataEntrada);
		reserva.setDataSaida(dataSaida);
		
		reserva.setValorTotal(Calculadora.calcularPrecoTotal(dataEntrada, dataSaida, quarto.getValor()));
	}
	
	public void reservar() {
		step = 0;

		reservaService.adicionar(reserva);
		
		filtrarReservas();
		
		FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Sucesso",  "Reserva realizada com sucesso") );
	}

	
	/*
	 *  GETS E SETS 
	 **/
	
	public Reserva getFiltroDisponibilidade() {
		return filtroDisponibilidade;
	}

	public void setFiltroDisponibilidade(Reserva filtroDisponibilidade) {
		this.filtroDisponibilidade = filtroDisponibilidade;
	}

	public Reserva getFiltroPesquisa() {
		return filtroPesquisa;
	}

	public void setFiltroPesquisa(Reserva filtroPesquisa) {
		this.filtroPesquisa = filtroPesquisa;
	}

	public Reserva getReserva() {
		return reserva;
	}

	public void setReserva(Reserva reserva) {
		this.reserva = reserva;
	}

	public int getStep() {
		return step;
	}

	public void setStep(int step) {
		this.step = step;
	}

	public List<Reserva> getReservasList() {
		if (reservasList == null) {
			filtrarReservas();
		}
		
		return reservasList;
	}

	public void setReservasList(List<Reserva> reservasList) {
		this.reservasList = reservasList;
	}

}
