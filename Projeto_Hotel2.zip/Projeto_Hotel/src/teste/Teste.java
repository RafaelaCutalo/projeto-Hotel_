package teste;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import modelo.Hospede;

public class Teste {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("hotel");
		
		Hospede hospede = new Hospede();
		hospede.setNome("Josenildo Freitas");
		
		EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		
		manager.persist(hospede);
		
		
		
		manager.getTransaction().commit();
		
		System.out.println("Id do hospede: " + hospede.getId());
		
		manager.close();
		factory.close();
	}
	
}
