package service;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.transaction.Transactional;

import dao.HospedeDao;
import dao.ReservaDao;
import exception.HotelException;
import modelo.Hospede;
import modelo.Reserva;

@Transactional
@Stateless
public class ReservaServiceImpl implements ReservaService {

	@Inject
	private ReservaDao reservaDao;

	@Inject
	private HospedeDao hospedeDao;

	@Override
	public Reserva adicionar(Reserva reserva) {
		hospedeDao.inserir(reserva.getHospede());
		reservaDao.inserir(reserva);
		
		return reserva;
	}
	
	@Override
	public void cancelar(Long id) {
		
		Reserva reserva = obter(id);
		
		if (reserva == null) {
			throw new HotelException("Reserva "+id+" não encontrada");
		}
		
		reservaDao.remover(id);
	}

	@Override
	public Reserva obter(Long id) {
		return reservaDao.obter(id);
	}

	@Override
	public void alterar(Reserva reserva) {
		Reserva reservaEncontrada = obter(reserva.getId());
		
		if (reserva == null) {
			throw new HotelException("Reserva "+reserva.getId()+" não encontrada");
		}
		
		Hospede hospedeAntigo = reservaEncontrada.getHospede();
		
		Hospede hospede = reserva.getHospede();
		hospedeAntigo.setCpf(hospede.getCpf());
		hospedeAntigo.setEndereco(hospede.getEndereco());
		hospedeAntigo.setNome(hospede.getNome());
		
		hospedeDao.atualizar(hospedeAntigo);
	}
	
	@Override
	public List<Reserva> pesquisarReservas(Reserva filtro) {
		return reservaDao.pesquisarReservas(filtro);
	}

	
}
