package service;

import java.util.Date;
import java.util.List;

import modelo.Quarto;

public interface QuartoService {

	/**
	 * Cadastra 30 quartos quando não possui nenhum quarto cadastrado
	 * 
	 * @return Retorna true  se cadastrou, e false caso contrário
	 */
	boolean cadastrarQuartosSeNecessario();

	/**
	 * Lista todos os quartos do hotel.
	 * 
	 * @return
	 */
	List<Quarto> listar();

	List<Quarto> pesquisarQuartosDisponiveis(Date entrada, Date saida);

}
