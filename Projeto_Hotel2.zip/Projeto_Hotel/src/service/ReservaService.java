package service;

import java.util.List;

import modelo.Reserva;

public interface ReservaService {

	Reserva adicionar(Reserva reserva);

	void cancelar(Long id);

	Reserva obter(Long id);

	void alterar(Reserva reserva);

	List<Reserva> pesquisarReservas(Reserva filtro);

}
