package service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.transaction.Transactional;

import dao.QuartoDao;
import modelo.Quarto;

@Transactional
@Stateless
public class QuartoServiceImpl implements QuartoService {
	
	@Inject
	private QuartoDao quartoDao;

	@Override
	public boolean cadastrarQuartosSeNecessario() {
		List<Quarto> quartoList = quartoDao.listar();
		if (quartoList.isEmpty()) {
			for (int i = 1;i <= 30; i++) {
				Quarto quarto = new Quarto();
				
				quarto.setId(i);
				quarto.setValor(new BigDecimal("100"));
				
				quartoDao.inserir(quarto);
			}
			
			return true;
		}
		
		return false;
	}
	
	@Override
	public List<Quarto> pesquisarQuartosDisponiveis(Date entrada, Date saida) {
		return quartoDao.pesquisarQuartosDisponiveis(entrada, saida);
	}

	@Override
	public List<Quarto> listar() {
		return quartoDao.listar();
	}

}
