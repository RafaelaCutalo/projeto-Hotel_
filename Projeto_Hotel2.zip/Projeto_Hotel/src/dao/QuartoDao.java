package dao;

import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import modelo.Quarto;

public class QuartoDao {

	@Inject
	private EntityManager manager;

	public List<Quarto> listar() {
		Query query = manager.createQuery("from Quarto");
		return query.getResultList();
	}
	
	public void inserir(Quarto quarto) {
		manager.persist(quarto);
	}
	
	public Quarto obter(Quarto id) {
		return manager.find(Quarto.class, id);
	}
	
	public List<Quarto> pesquisarQuartosDisponiveis(Date dataEntrada, Date dataSaida) {
		Query query = manager.createQuery("from Quarto q where not exists (select 1 from Reserva r where r.quarto.id = q.id and date(r.dataEntrada) >= date(:dataEntrada) and date(:dataSaida) <= date(r.dataSaida) ) order by q.id");
		query.setParameter("dataEntrada", dataEntrada);
		query.setParameter("dataSaida", dataSaida);
		
		
		return query.getResultList();
	}

}
