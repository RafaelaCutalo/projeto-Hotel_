package dao;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import modelo.Reserva;

public class ReservaDao {

	@Inject
	private EntityManager manager;

	public void inserir(Reserva reserva) {
		manager.persist(reserva);
	}
	
	public void atualizar(Reserva reserva) {
		manager.merge(reserva);
	}
	
	public void remover(Long id) {
		Reserva reserva = manager.find(Reserva.class, id);
		manager.remove(reserva);
	}

	public Reserva obter(Long id) {
		return manager.find(Reserva.class, id);
	}

	public List<Reserva> listarAs10ReservasAposHoje() {
		Query query = manager.createQuery("from Reserva where date(dataEntrada) >= date(sysdate) order by dataEntrada ");
		query.setMaxResults(10);
		
		return query.getResultList();
	}

	public List<Reserva> pesquisarReservas(Reserva reserva) {
		StringBuffer sql = new StringBuffer("from Reserva where 1 = 1");
		
		if (reserva.getDataEntrada() != null) {
			sql.append(" and date(dataEntrada) >= date(:dataEntrada) ");
		}
		
		if (reserva.getDataSaida() != null) {
			sql.append(" and date(dataSaida) <= date(:dataSaida) ");
		}
		
		sql.append(" order by date(dataEntrada) ");
		
		Query query = manager.createQuery(sql.toString());
		
		if (reserva.getDataEntrada() != null) {
			query.setParameter("dataEntrada", reserva.getDataEntrada());
		}
		
		if (reserva.getDataSaida() != null) {
			query.setParameter("dataSaida", reserva.getDataSaida());
		}
		
		return query.getResultList();
		
	}
	
}
