package dao;

import java.util.List;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.Query;

import modelo.Hospede;

public class HospedeDao {

	@Inject
	private EntityManager manager;
	
	public void inserir(Hospede hospede) {		
		manager.persist(hospede);
	}
	
	public void remover(int id) {
		manager.remove(manager.merge(manager.find(Hospede.class, id)));
	}

	public void atualizar(Hospede hospede) {
		manager.merge(hospede);
	}
	
	public Hospede obter(Long id) {
		return manager.find(Hospede.class, id);
	}
	
	public List<Hospede> listarHospedes() {
		Query query = manager.createQuery("from Hospede");
		return query.getResultList();
	}

}
