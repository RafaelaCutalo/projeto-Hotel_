create database hotel;
